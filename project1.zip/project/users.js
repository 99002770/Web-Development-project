//Example for creating JSON Rest server....
const app = require('express')();
const parser = require("body-parser");
const cors = require('cors');
const fs = require("fs");
const dir = __dirname;


//middleware....
app.use(parser.urlencoded({ extended: true }));
app.use(parser.json());
app.use(cors());//use the Cors so that it enables CORS...

//GET(Reading), POST(Adding), PUT(Updating), DELETE(Deleting) data....
let users = [];//blank array...

function readData(){
    const filename = "userData.json";//new file... 
    const jsonContent = fs.readFileSync(filename, 'utf-8');
    users = JSON.parse(jsonContent);
}

function saveData(){
    const filename = "userData.json";
    const jsonData = JSON.stringify(users);
    fs.writeFileSync(filename, jsonData, 'utf-8');
}
app.get("/users", (req, res)=>{
    readData();
    res.send(JSON.stringify(users));    
})

app.get("/users/:id", (req, res)=>{
    const userid = req.params.id;
    if(users.length == 0){
        readData();
    }
    let foundRec = users.find((u) => u.userId == userid);
    if(foundRec == null)
        throw "User not found";
    res.send(JSON.stringify(foundRec))
})

app.put("/users", (req, res)=>{
    if(users.length == 0)
        readData();//Fill the array if it is not loaded....
    let body = req.body;
    //iterate thro the collection
    for (let index = 0; index < users.length; index++) {
        let element = users[index];
        if (element.userId == body.userId) {//find the matching record
            element.userName = body.userName;
            element.userCourse = body.userCourse;
            saveData();
            res.send("User updated successfully");
        }
    }
    //update the data
    //exit the function....
})

app.post('/users', (req, res)=>{
    if (users.length == 0)
        readData();//Fill the array if it is not loaded....
    let body = req.body;//parsed data from the POST...
    users.push(body);  
    saveData();//updating to the JSON file...
    res.send("User added successfully");
})
app.delete("/users/:id", (req, res) => {
    if (users.length == 0)
        readData(); 
    var flag=1;
    const userid = req.params.id;
    console.log(userid)
    for (let index = 0; index < users.length; index++) {
        let element = users[index];
        if (element.userId == userid) { 
            users.splice(index,1);
            res.send("User Deleted Successfully");
            saveData();
            readData();
            flag = 0;
         }
     }
    if (flag >= 1) {
        res.send("Error in Deleting");
     }
    })

app.listen(1234, ()=>{
    console.log("Server available at 1234");
})